// Background script for DV Efnisblokkari
// Cross-browser compatibility layer
const browserAPI = typeof browser !== 'undefined' ? browser : chrome;

async function setDefaults() {
    try {
        const result = await browserAPI.storage.sync.get(['block433', 'blockFokus', 'blockEyjan', 'blockKynning']);
        const defaults = {};
        if (result.block433 === undefined) defaults.block433 = true;
        if (result.blockFokus === undefined) defaults.blockFokus = true;
        if (result.blockEyjan === undefined) defaults.blockEyjan = true;
        if (result.blockKynning === undefined) defaults.blockKynning = true;
        
        if (Object.keys(defaults).length > 0) {
            await browserAPI.storage.sync.set(defaults);
        }
    } catch (error) {
        console.error('Error setting defaults:', error);
    }
}

browserAPI.runtime.onInstalled.addListener(() => {
    setDefaults();
});

browserAPI.runtime.onStartup.addListener(() => {
    setDefaults();
});

// Listen for messages from popup and content scripts
browserAPI.runtime.onMessage.addListener(async function(request, sender, sendResponse) {
    if (request.action === 'getState') {
        try {
            const result = await browserAPI.storage.sync.get(['block433', 'blockFokus', 'blockEyjan', 'blockKynning']);
            sendResponse({
                block433: result.block433 !== false,
                blockFokus: result.blockFokus !== false,
                blockEyjan: result.blockEyjan !== false,
                blockKynning: result.blockKynning !== false
            });
        } catch (error) {
            console.error('Error getting state:', error);
            sendResponse({ error: 'Failed to get state' });
        }
        return true; // Indicates we will send a response asynchronously
    }
});